const data = [
    {
        name : "D",
        city: "Vadodara"
    },
    {
        name : "n",
        city: "anand"
    }

];

export default data;