import React from 'react'

export const Home = () => {
    let name = "weltec"
  return (
    <div>{name}</div>
  )
}
